publog = {
    [2014 06 03 11 33 00],'submission','Science';
    [2014 06 21 01 46 00],'submission','PNAS';
    [2014 10 28 12 00 00],'resubmission','PNAS';
    [2015 01 02 01 42 00],'resubmission','PNAS';
    [2015 01 09 13 10 00],'accepted','Nature';
%%   [2011 10 23 15 27 00],'submission','PLoS ONE';
%%   [2011 11 14 23 00 00],'resubmission','PLoS ONE';
%%   [2011 11 29 17 32 03],'accepted','PLoS ONE';
%%   [2012 01 11 17 00 00],'published','PLoS ONE';
};
